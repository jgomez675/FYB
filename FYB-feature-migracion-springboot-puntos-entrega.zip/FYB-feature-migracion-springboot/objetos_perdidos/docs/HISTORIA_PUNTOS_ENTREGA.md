# Historia de usuario: puntos de entrega y ubicación del objeto

> Como estudiante de la Sergio, quiero saber dónde debo dejar un objeto que encontré y conocer la
> ubicación exacta de dónde se encuentra mi objeto actualmente para poder reclamarlo.

## Qué hace

1. **Dónde dejar un objeto.** Pantalla `#/puntos-entrega` (enlace "Puntos de entrega" en la barra
   superior) con los dos lugares donde se entrega un objeto encontrado:
   - **Bloque F - Objetos perdidos**
   - **Seguridad**
2. **Publicar un objeto "Encontrado".** Al elegir el estado *Encontrado* en el formulario aparece
   "¿Dónde dejaste el objeto?" y es obligatorio. Si el estado es *Perdido* no se pide.
3. **Ver dónde está mi objeto.** En el detalle de un objeto encontrado:
   - Quien lo **publicó** ve la ubicación actual y puede cambiarla (por ejemplo, si lo trasladan).
   - Cualquier otro estudiante ve solo un aviso; **la ubicación exacta aparece únicamente después de
     verificar la característica privada** ("Verificar propiedad"). Así nadie puede ir a recoger un
     objeto que no es suyo.

## Criterios de aceptación

- [x] Un estudiante con sesión puede consultar los puntos de entrega (nombre, lugar, indicaciones, horario).
- [x] Un objeto "Encontrado" no se publica sin un punto de entrega válido (mensaje claro, código 400).
- [x] La lista y el detalle de objetos **no** incluyen la ubicación.
- [x] La ubicación solo se entrega al autor o a quien acierta la característica privada.
- [x] Solo el autor puede cambiar la ubicación, y solo mientras el objeto no esté devuelto.
- [x] Máximo 10 intentos de verificación cada 10 minutos por usuario y objeto (código 429).

## API nueva

| Método y ruta | Qué hace | Errores |
|---|---|---|
| `GET /api/entrega/puntos` | Lista de puntos de entrega | 401 |
| `POST /api/entrega/{id}/consultar` | Ubicación actual. Cuerpo: `{ "caracteristica": "..." }` (el autor no la necesita) | 401, 403, 404, 429 |
| `PUT /api/entrega/{id}/ubicacion` | El autor cambia el punto. Cuerpo: `{ "ubicacionId": "seguridad" }` | 400, 401, 403, 404 |
| `POST /api/objetos` *(existente)* | Ahora acepta `ubicacionId` (obligatorio si `estado` es "Encontrado") | 400 |

Los errores de esta función responden `{ "ok": false, "mensaje": "..." }`, que es lo que lee el front.

## Dónde se guardan los datos

- `data/puntos_entrega.txt` (**va al repositorio**): catálogo `id|nombre|lugar|indicaciones|horario`.
  Para agregar un punto basta con añadir una línea. Si el archivo no existe se usan los dos por defecto.
- `data/ubicaciones_objetos.txt` (**no va al repositorio**, ya está en `.gitignore`): `idObjeto|idPunto`.
  Se guarda aparte para no cambiar el formato de `objetos.txt`.

## Código nuevo (carpetas propias)

```
src/main/java/back/entrega/
├── EntregaException.java            error con código HTTP y mensaje
├── ManejadorErroresEntrega.java     lo convierte en JSON (solo atiende EntregaException)
├── SesionUtil.java                  lee la sesión; sin sesión -> 401
├── EntregaPublicacion.java          validar / registrar al publicar un objeto
├── model/PuntoEntrega.java
├── service/PuntoEntregaService.java        catálogo
├── service/UbicacionObjetoService.java     ubicación de cada objeto (escritura atómica)
├── controller/EntregaController.java       los 3 endpoints
└── limite/                                 tope de intentos de verificación
    ├── LimiteIntentosInterceptor.java
    └── LimiteIntentosConfig.java

src/main/resources/static/entrega/
├── EntregaApi.js            llamadas al servidor
├── EntregaComponentes.js    selector de punto, tarjeta de ubicación, bloque del detalle
├── PuntosEntregaView.js     pantalla "Puntos de entrega"
└── entrega.css
```

## Cambios en archivos existentes (solo 49 líneas añadidas y 3 reemplazadas)

| Archivo | Cambio |
|---|---|
| `controller/ObjetosController.java` | +2 llamadas a `EntregaPublicacion` (validar antes de guardar, registrar después) |
| `static/index.html` | +1 hoja de estilos y +3 scripts |
| `static/Main.js` | +1 ruta `#/puntos-entrega` |
| `static/components/layout.js` | +1 enlace "Puntos de entrega" en la barra superior |
| `static/servicios/ObjetosApi.js` | `guardarObjeto` recibe y envía `ubicacionId` |
| `static/objetos/RegistrarObjetoView.js` | selector de punto, visible solo si el estado es "Encontrado" |
| `static/objetos/DetalleObjetoView.js` | muestra el bloque de entrega y la ubicación tras verificar |
| `.gitignore` | +`data/ubicaciones_objetos.txt` |

## Cómo probarlo a mano

1. `./run.sh` y abrir http://localhost:8080. Crear dos cuentas `@usa.edu.co` (Ana y Beto).
2. **Ana:** "Puntos de entrega" en la barra -> ver Bloque F y Seguridad.
3. **Ana:** publicar un objeto *Encontrado* sin elegir punto -> debe pedirlo. Elegir *Bloque F* y publicar.
4. **Beto:** abrir ese objeto -> solo ve el aviso. Escribir una característica incorrecta -> "no coincide".
   Escribir la correcta -> aparece "Tu objeto está en: Bloque F - Objetos perdidos".
5. **Ana:** abrir su objeto -> ve el punto actual; cambiarlo a *Seguridad*. Beto lo verifica de nuevo y ve Seguridad.
6. **Beto:** repetir más de 10 verificaciones seguidas en un objeto -> mensaje de "Demasiados intentos".
7. Publicar un objeto *Perdido*: no pide punto y su detalle no muestra nada de entrega.

## Lo que queda fuera (para otras historias)

- **Puntos de recompensa del caso "Encontrado".** `POST /api/objetos/{id}/verificar` (existente) registra
  a quien verifica como *descubridor*. Para objetos "Perdidos" tiene sentido; en uno "Encontrado" quien
  verifica es el dueño y quien encontró es el autor, así que el reparto de puntos hay que rediseñarlo.
- **`validar-devolucion` sigue activo** y permite ganar puntos sin pasar por la verificación.
- **Errores genéricos en controladores viejos:** siguen lanzando `RuntimeException` y el front muestra
  un mensaje genérico. `ManejadorErroresEntrega` arregla esto solo para la función nueva.
- **Horario de los puntos** está vacío: complétalo en `data/puntos_entrega.txt` si lo quieres mostrar.
- El tope de intentos vive en memoria: se reinicia cuando se reinicia el servidor.
