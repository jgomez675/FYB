/* Cliente de EntregaController.java: puntos de entrega y ubicación de los objetos encontrados. */
(function (App) {
  "use strict";

  const { ApiClient, ErrorApi } = App.front.api;

  App.front.entrega = App.front.entrega || {};

  class EntregaApi {
    // Lista de lugares donde se puede dejar un objeto encontrado.
    static async puntos() {
      const r = await ApiClient.solicitar("GET", "/api/entrega/puntos");
      if (r.estado === 200 && r.datos) return r.datos.puntos || [];
      throw new ErrorApi(ApiClient.mensajeDe(r), r.estado);
    }

    // Ubicación actual del objeto. El dueño debe enviar la característica privada;
    // quien lo publicó puede consultarla sin ella.
    // Devuelve { tieneUbicacion, ubicacion?, esAutor? } o { ok: false, mensaje }.
    static async consultarUbicacion(id, caracteristica) {
      const r = await ApiClient.solicitar(
        "POST",
        "/api/entrega/" + encodeURIComponent(id) + "/consultar",
        { caracteristica: caracteristica || "" }
      );

      if (r.estado === 200 && r.datos) return r.datos;
      if (r.estado === 401) throw new ErrorApi(ApiClient.mensajeDe(r), 401);
      return { ok: false, tieneUbicacion: false, mensaje: ApiClient.mensajeDe(r) };
    }

    // Quien publicó el objeto cambia dónde está.
    static async cambiarUbicacion(id, ubicacionId) {
      const r = await ApiClient.solicitar(
        "PUT",
        "/api/entrega/" + encodeURIComponent(id) + "/ubicacion",
        { ubicacionId }
      );

      if (r.estado === 200 && r.datos && r.datos.ok) return r.datos;
      if (r.estado === 401) throw new ErrorApi(ApiClient.mensajeDe(r), 401);
      return { ok: false, mensaje: ApiClient.mensajeDe(r) };
    }
  }

  App.front.api.EntregaApi = EntregaApi;
})(window.App);
