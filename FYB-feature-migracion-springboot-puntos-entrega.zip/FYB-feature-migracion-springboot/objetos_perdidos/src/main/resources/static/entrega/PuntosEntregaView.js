/* Pantalla "Puntos de entrega": dónde dejar un objeto que encontraste. Ruta: #/puntos-entrega */
(function (App) {
  "use strict";

  const { h } = App.front.components.dom;
  const { pantalla } = App.front.components.layout;
  const { ponerTitulo } = App.front.components.navigation;
  const { EntregaApi } = App.front.api;

  class PuntosEntregaView {
    async mostrar({ usuario }) {
      ponerTitulo("Puntos de entrega");

      const puntos = await EntregaApi.puntos();

      const lista = h(
        "div",
        { class: "grid" },
        ...puntos.map((p) =>
          h("article", { class: "card obj" },
            h("div", { class: "obj-body" }, App.front.entrega.tarjetaPunto(p)))
        )
      );

      return pantalla(
        usuario,
        h("div", { class: "page-head" },
          h("div", {},
            h("h1", {}, "¿Dónde dejo un objeto que encontré?"),
            h("p", { class: "lede" },
              "Deja el objeto en uno de estos puntos y publícalo como «Encontrado» eligiendo dónde lo dejaste.")
          ),
          h("a", { class: "btn btn-primary", href: "#/publicar" }, "Publicar objeto encontrado")
        ),
        puntos.length
          ? lista
          : h("section", { class: "card notice" }, h("p", {}, "Todavía no hay puntos de entrega configurados."))
      );
    }
  }

  App.front.entrega = App.front.entrega || {};
  App.front.entrega.PuntosEntregaView = PuntosEntregaView;
})(window.App);
