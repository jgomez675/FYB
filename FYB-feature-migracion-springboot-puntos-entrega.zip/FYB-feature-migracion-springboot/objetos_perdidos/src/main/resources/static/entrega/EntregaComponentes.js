/*
 * Piezas de pantalla de los puntos de entrega. Las usan RegistrarObjetoView (elegir dónde dejaste
 * el objeto) y DetalleObjetoView (ver dónde está tu objeto), además de PuntosEntregaView.
 */
(function (App) {
  "use strict";

  const { h, mostrarMensaje, ocupado } = App.front.components.dom;
  const { EntregaApi } = App.front.api;

  App.front.entrega = App.front.entrega || {};

  // Datos de un punto: nombre, dónde queda, qué hacer y horario (si lo hay).
  function tarjetaPunto(punto, titulo) {
    return h(
      "div",
      { class: "entrega-punto" },
      titulo ? h("p", { class: "entrega-titulo" }, titulo) : null,
      h("h3", { class: "entrega-nombre" }, punto.nombre),
      h("p", { class: "entrega-dato" }, h("span", { class: "k" }, "Dónde: "), punto.lugar),
      h("p", { class: "entrega-dato" }, punto.indicaciones),
      punto.horario
        ? h("p", { class: "entrega-dato" }, h("span", { class: "k" }, "Horario: "), punto.horario)
        : null
    );
  }

  // <select> con los puntos de entrega. Devuelve { control, wrap, cargar }.
  // "cargar()" pide la lista al servidor; wrap arranca oculto y se muestra con mostrar(true).
  function selectorPunto() {
    const control = h("select", { id: "ubicacionId", name: "ubicacionId" },
      h("option", { value: "" }, "Selecciona un punto de entrega"));
    const detalle = h("div", {});
    const aviso = h("p", { class: "msg", role: "alert" });
    let puntos = [];

    control.addEventListener("change", () => {
      const elegido = puntos.find((p) => p.id === control.value);
      detalle.replaceChildren(elegido ? tarjetaPunto(elegido) : "");
    });

    const wrap = h(
      "div",
      { class: "field", hidden: true },
      h("label", { for: "ubicacionId" }, "¿Dónde dejaste el objeto?"),
      control,
      h("small", { class: "help-text" },
        "Déjalo en uno de estos puntos para que su dueño pueda reclamarlo."),
      detalle,
      aviso
    );

    async function cargar() {
      try {
        puntos = await EntregaApi.puntos();
        control.replaceChildren(
          h("option", { value: "" }, "Selecciona un punto de entrega"),
          ...puntos.map((p) => h("option", { value: p.id }, p.nombre))
        );
      } catch (e) {
        mostrarMensaje(aviso, "No se pudieron cargar los puntos de entrega.", "error");
      }
    }

    return {
      control,
      wrap,
      cargar,
      mostrar(visible) {
        wrap.hidden = !visible;
      },
    };
  }

  // Bloque del detalle de un objeto:
  //  - al autor de un objeto encontrado le muestra dónde está y le deja cambiarlo;
  //  - a los demás, un aviso: la ubicación exacta se ve al verificar que el objeto es tuyo.
  function bloqueDetalle(usuario, objeto) {
    const contenedor = h("div", { class: "entrega-bloque" });

    if (objeto.estado !== "Encontrado") {
      return contenedor;
    }

    const esAutor = objeto.correoUsuario && usuario && objeto.correoUsuario.toLowerCase() === usuario.correo.toLowerCase();

    if (!esAutor) {
      contenedor.append(
        h("p", { class: "help-text" },
          "Este objeto fue dejado en un punto de entrega. Verifica que es tuyo para ver dónde está.")
      );
      return contenedor;
    }

    // Autor: se consulta la ubicación y se ofrece cambiarla.
    (async () => {
      try {
        const r = await EntregaApi.consultarUbicacion(objeto.id);

        if (!r.tieneUbicacion) {
          contenedor.append(h("p", { class: "help-text" }, "Este objeto aún no tiene punto de entrega registrado."));
        } else {
          contenedor.append(tarjetaPunto(r.ubicacion, "El objeto está en:"));
        }

        const selector = selectorPunto();
        await selector.cargar();
        selector.mostrar(true);
        selector.wrap.querySelector("label").textContent = "Cambiar punto de entrega";
        if (r.tieneUbicacion) selector.control.value = r.ubicacion.id;

        const mensaje = h("p", { class: "msg", role: "alert" });
        const guardar = h("button", { class: "btn btn-secondary", type: "button" }, "Guardar ubicación");

        guardar.addEventListener("click", async () => {
          if (!selector.control.value) {
            mostrarMensaje(mensaje, "Selecciona un punto de entrega.", "error");
            return;
          }

          ocupado(guardar, true);
          try {
            const res = await EntregaApi.cambiarUbicacion(objeto.id, selector.control.value);
            if (res.ok) {
              mostrarMensaje(mensaje, "Ubicación actualizada.", "success");
              contenedor.querySelector(".entrega-punto")?.replaceWith(tarjetaPunto(res.ubicacion, "El objeto está en:"));
            } else {
              mostrarMensaje(mensaje, res.mensaje, "error");
            }
          } catch (error) {
            mostrarMensaje(mensaje, error.message, "error");
          } finally {
            ocupado(guardar, false);
          }
        });

        contenedor.append(selector.wrap, guardar, mensaje);
      } catch (error) {
        contenedor.append(h("p", { class: "msg error" }, error.message));
      }
    })();

    return contenedor;
  }

  // Se llama cuando el dueño acaba de verificar el objeto: consulta y muestra dónde está.
  async function mostrarUbicacion(zona, objeto, caracteristica) {
    if (objeto.estado !== "Encontrado") return;

    try {
      const r = await EntregaApi.consultarUbicacion(objeto.id, caracteristica);

      if (r.tieneUbicacion) {
        zona.append(tarjetaPunto(r.ubicacion, "Tu objeto está en:"));
      } else if (r.ok === false && r.mensaje) {
        zona.append(h("p", { class: "msg error" }, r.mensaje));
      } else {
        zona.append(h("p", { class: "help-text" }, "Todavía no hay un punto de entrega registrado para este objeto."));
      }
    } catch (error) {
      zona.append(h("p", { class: "msg error" }, error.message));
    }
  }

  App.front.entrega.tarjetaPunto = tarjetaPunto;
  App.front.entrega.selectorPunto = selectorPunto;
  App.front.entrega.bloqueDetalle = bloqueDetalle;
  App.front.entrega.mostrarUbicacion = mostrarUbicacion;
})(window.App);
