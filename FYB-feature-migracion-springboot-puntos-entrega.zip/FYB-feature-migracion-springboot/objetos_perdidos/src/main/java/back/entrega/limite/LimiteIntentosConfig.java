package back.entrega.limite;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class LimiteIntentosConfig implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registro) {
        registro.addInterceptor(new LimiteIntentosInterceptor())
                .addPathPatterns("/api/objetos/*/verificar", "/api/entrega/*/consultar");
    }
}
