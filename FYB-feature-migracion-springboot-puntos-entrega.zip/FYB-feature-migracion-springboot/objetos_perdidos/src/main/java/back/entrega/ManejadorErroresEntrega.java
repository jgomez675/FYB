package back.entrega;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Map;

/**
 * Convierte EntregaException en una respuesta JSON { "mensaje": ... } con el código HTTP correcto,
 * que es lo que lee el front (ApiClient.mensajeDe). Solo atiende EntregaException: el resto de
 * errores de la aplicación se comportan igual que antes.
 */
@RestControllerAdvice
public class ManejadorErroresEntrega {

    @ExceptionHandler(EntregaException.class)
    public ResponseEntity<Map<String, Object>> manejar(EntregaException e) {
        return ResponseEntity
                .status(e.getEstado())
                .body(Map.of("ok", false, "mensaje", e.getMessage()));
    }
}
