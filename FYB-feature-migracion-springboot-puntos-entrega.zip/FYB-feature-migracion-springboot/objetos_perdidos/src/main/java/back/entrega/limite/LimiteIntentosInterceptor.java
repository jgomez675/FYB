package back.entrega.limite;

import back.api.SessionManager;
import back.entrega.SesionUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.HandlerInterceptor;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Limita cuántas veces un usuario puede intentar demostrar que un objeto es suyo
 * (POST /api/objetos/{id}/verificar y POST /api/entrega/{id}/consultar): 10 intentos cada
 * 10 minutos por usuario y objeto. Sin este tope se podría adivinar la característica privada
 * y, con ella, la ubicación del objeto. Va aparte para no modificar los controladores existentes.
 */
public class LimiteIntentosInterceptor implements HandlerInterceptor {

    private static final int MAX_INTENTOS = 10;
    private static final long VENTANA_MS = 10L * 60 * 1000;

    private static final Pattern RUTA = Pattern.compile("/api/(?:objetos|entrega)/(\\d+)/");

    private static final Map<String, Deque<Long>> intentos = new ConcurrentHashMap<>();

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws IOException {

        if (!"POST".equals(request.getMethod())) {
            return true;
        }

        SessionManager.Sesion sesion = SessionManager.obtener(SesionUtil.leerToken(request));
        if (sesion == null) {
            return true; // sin sesión, el controlador responde 401
        }

        Matcher m = RUTA.matcher(request.getRequestURI());
        if (!m.find()) {
            return true;
        }

        String clave = sesion.correo().toLowerCase() + "|" + m.group(1);
        long ahora = System.currentTimeMillis();

        Deque<Long> cola = intentos.computeIfAbsent(clave, k -> new ArrayDeque<>());

        synchronized (cola) {
            while (!cola.isEmpty() && ahora - cola.peekFirst() > VENTANA_MS) {
                cola.pollFirst();
            }

            if (cola.size() >= MAX_INTENTOS) {
                response.setStatus(429);
                response.setContentType("application/json;charset=UTF-8");
                response.getWriter().write(
                        "{\"ok\":false,\"mensaje\":\"Demasiados intentos. Espera unos minutos e inténtalo de nuevo.\"}");
                return false;
            }

            cola.addLast(ahora);
        }

        if (intentos.size() > 5000) {
            intentos.values().removeIf(q -> {
                synchronized (q) {
                    return q.isEmpty() || ahora - q.peekLast() > VENTANA_MS;
                }
            });
        }

        return true;
    }
}
