package back.entrega.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Dónde está ahora cada objeto encontrado. Se guarda aparte, en data/ubicaciones_objetos.txt
 * (formato: idObjeto|idPuntoEntrega), para no tocar el formato de objetos.txt.
 */
public class UbicacionObjetoService {

    private static final Path ARCHIVO = Paths.get("data", "ubicaciones_objetos.txt");

    private static final Map<Integer, String> ubicaciones = new HashMap<>();

    static {
        cargar();
    }

    private static void cargar() {
        if (!Files.exists(ARCHIVO)) {
            return;
        }

        try (BufferedReader lector = Files.newBufferedReader(ARCHIVO)) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                if (linea.isBlank()) {
                    continue;
                }

                String[] p = linea.split("\\|", -1);
                if (p.length != 2) {
                    continue;
                }

                try {
                    ubicaciones.put(Integer.parseInt(p[0].trim()), p[1].trim());
                } catch (NumberFormatException ignored) {
                    // Línea dañada: se ignora.
                }
            }
        } catch (IOException e) {
            System.err.println("No se pudieron cargar las ubicaciones: " + e.getMessage());
        }
    }

    /** Id del punto de entrega donde está el objeto, o null si no tiene ubicación registrada. */
    public static synchronized String obtener(int idObjeto) {
        return ubicaciones.get(idObjeto);
    }

    /** Registra (o cambia) la ubicación. Devuelve false si no se pudo guardar en disco. */
    public static synchronized boolean registrar(int idObjeto, String idPunto) {
        String anterior = ubicaciones.put(idObjeto, idPunto);

        try {
            guardar();
            return true;
        } catch (IOException e) {
            if (anterior == null) {
                ubicaciones.remove(idObjeto);
            } else {
                ubicaciones.put(idObjeto, anterior);
            }
            System.err.println("No se pudo guardar la ubicación: " + e.getMessage());
            return false;
        }
    }

    // Escritura atómica: se escribe en un temporal y se mueve, para no dejar el archivo a medias.
    private static void guardar() throws IOException {
        Path carpeta = ARCHIVO.toAbsolutePath().getParent();
        Files.createDirectories(carpeta);

        List<String> lineas = new ArrayList<>();
        for (Map.Entry<Integer, String> e : ubicaciones.entrySet()) {
            lineas.add(e.getKey() + "|" + e.getValue());
        }

        Path temporal = Files.createTempFile(carpeta, "ubicaciones_", ".tmp");
        try {
            try (BufferedWriter escritor = Files.newBufferedWriter(temporal)) {
                for (String linea : lineas) {
                    escritor.write(linea);
                    escritor.newLine();
                }
            }
            Files.move(temporal, ARCHIVO, StandardCopyOption.REPLACE_EXISTING);
        } finally {
            Files.deleteIfExists(temporal);
        }
    }
}
