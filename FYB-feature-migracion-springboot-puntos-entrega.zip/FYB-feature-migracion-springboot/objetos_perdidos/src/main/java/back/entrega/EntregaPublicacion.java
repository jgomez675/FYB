package back.entrega;

import back.entrega.model.PuntoEntrega;
import back.entrega.service.PuntoEntregaService;
import back.entrega.service.UbicacionObjetoService;
import back.model.ObjetoPerdido;
import back.service.ObjetoPerdidoService;

import java.util.Comparator;

/**
 * Las dos llamadas que hace ObjetosController.publicarObjeto: una antes de guardar el objeto
 * (validar) y otra justo después (registrar). Son las únicas líneas nuevas en ese controlador.
 */
public final class EntregaPublicacion {

    private EntregaPublicacion() {
    }

    /** Un objeto "Encontrado" exige un punto de entrega válido. Si es "Perdido" no se pide nada. */
    public static void validar(String estado, String ubicacionId) {
        if (!esEncontrado(estado)) {
            return;
        }

        if (ubicacionId == null || ubicacionId.isBlank()) {
            throw new EntregaException(400, "Selecciona dónde dejaste el objeto.");
        }

        if (PuntoEntregaService.obtener(ubicacionId) == null) {
            throw new EntregaException(400, "El punto de entrega seleccionado no existe.");
        }
    }

    /** Guarda la ubicación del objeto que este autor acaba de publicar. */
    public static void registrar(String correoAutor, String estado, String ubicacionId) {
        if (!esEncontrado(estado)) {
            return;
        }

        PuntoEntrega punto = PuntoEntregaService.obtener(ubicacionId);
        if (punto == null) {
            return;
        }

        // El objeto recién guardado es el de mayor id entre los de este autor.
        ObjetoPerdido nuevo = ObjetoPerdidoService.obtenerObjetos().stream()
                .filter(o -> o.getCorreoUsuario() != null && o.getCorreoUsuario().equalsIgnoreCase(correoAutor))
                .max(Comparator.comparingInt(ObjetoPerdido::getId))
                .orElse(null);

        if (nuevo != null) {
            UbicacionObjetoService.registrar(nuevo.getId(), punto.id());
        }
    }

    static boolean esEncontrado(String estado) {
        return estado != null && "Encontrado".equalsIgnoreCase(estado.trim());
    }
}
