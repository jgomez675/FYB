package back.entrega.model;

/**
 * Lugar de la universidad donde se deja un objeto encontrado.
 *
 * @param id           identificador estable (ej. "bloque-f")
 * @param nombre       nombre para mostrar
 * @param lugar        dónde queda, en una línea
 * @param indicaciones qué debe hacer quien entrega el objeto
 * @param horario      horario de atención (puede venir vacío)
 */
public record PuntoEntrega(String id, String nombre, String lugar, String indicaciones, String horario) {
}
