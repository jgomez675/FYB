package back.entrega.controller;

import back.api.SessionManager;
import back.entrega.EntregaException;
import back.entrega.SesionUtil;
import back.entrega.model.PuntoEntrega;
import back.entrega.service.PuntoEntregaService;
import back.entrega.service.UbicacionObjetoService;
import back.model.ObjetoPerdido;
import back.service.ObjetoPerdidoService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Puntos de entrega y ubicación actual de los objetos encontrados.
 *
 * GET  /api/entrega/puntos               lista de lugares donde dejar un objeto
 * POST /api/entrega/{id}/consultar       ubicación actual del objeto (dueño verificado o autor)
 * PUT  /api/entrega/{id}/ubicacion       el autor cambia dónde está el objeto
 */
@RestController
@RequestMapping("/api/entrega")
public class EntregaController {

    @GetMapping("/puntos")
    public Map<String, Object> puntos(HttpServletRequest request) {
        SesionUtil.requerir(request);
        return Map.of("puntos", PuntoEntregaService.listar());
    }

    /**
     * La ubicación exacta no va en la lista ni en el detalle del objeto: solo se entrega a quien
     * publicó el objeto o a quien demuestra que es suyo con la característica privada.
     */
    @PostMapping("/{id}/consultar")
    public Map<String, Object> consultar(
            @PathVariable int id,
            @RequestBody(required = false) Map<String, Object> cuerpo,
            HttpServletRequest request) {

        SessionManager.Sesion sesion = SesionUtil.requerir(request);
        ObjetoPerdido objeto = buscar(id);

        Map<String, Object> respuesta = new HashMap<>();
        respuesta.put("ok", true);

        String puntoId = UbicacionObjetoService.obtener(id);
        PuntoEntrega punto = PuntoEntregaService.obtener(puntoId);

        if (!"Encontrado".equalsIgnoreCase(objeto.getEstado()) || objeto.estaDevuelto() || punto == null) {
            respuesta.put("tieneUbicacion", false);
            return respuesta;
        }

        boolean esAutor = objeto.getCorreoUsuario().equalsIgnoreCase(sesion.correo());

        if (!esAutor) {
            String dada = texto(cuerpo, "caracteristica").trim();
            String real = objeto.getCaracteristicaPrivada() == null ? "" : objeto.getCaracteristicaPrivada().trim();

            if (dada.isEmpty() || real.isEmpty() || !real.equalsIgnoreCase(dada)) {
                throw new EntregaException(403, "La característica no coincide.");
            }
        }

        respuesta.put("tieneUbicacion", true);
        respuesta.put("esAutor", esAutor);
        respuesta.put("ubicacion", punto);
        return respuesta;
    }

    @PutMapping("/{id}/ubicacion")
    public Map<String, Object> cambiarUbicacion(
            @PathVariable int id,
            @RequestBody Map<String, Object> cuerpo,
            HttpServletRequest request) {

        SessionManager.Sesion sesion = SesionUtil.requerir(request);
        ObjetoPerdido objeto = buscar(id);

        if (!objeto.getCorreoUsuario().equalsIgnoreCase(sesion.correo())) {
            throw new EntregaException(403, "Solo quien publicó el objeto puede cambiar su ubicación.");
        }

        if (!"Encontrado".equalsIgnoreCase(objeto.getEstado())) {
            throw new EntregaException(400, "Solo los objetos encontrados tienen punto de entrega.");
        }

        if (objeto.estaDevuelto()) {
            throw new EntregaException(400, "Este objeto ya fue devuelto.");
        }

        PuntoEntrega punto = PuntoEntregaService.obtener(texto(cuerpo, "ubicacionId"));
        if (punto == null) {
            throw new EntregaException(400, "El punto de entrega seleccionado no existe.");
        }

        if (!UbicacionObjetoService.registrar(id, punto.id())) {
            throw new EntregaException(500, "No se pudo guardar la ubicación. Inténtalo de nuevo.");
        }

        return Map.of("ok", true, "ubicacion", punto);
    }

    private ObjetoPerdido buscar(int id) {
        ObjetoPerdido objeto = ObjetoPerdidoService.obtenerObjeto(id);
        if (objeto == null) {
            throw new EntregaException(404, "No encontramos este objeto.");
        }
        return objeto;
    }

    private String texto(Map<String, Object> cuerpo, String clave) {
        if (cuerpo == null) {
            return "";
        }
        Object valor = cuerpo.get(clave);
        return valor == null ? "" : valor.toString();
    }
}
