package back.entrega;

import back.api.SessionManager;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;

/** Lee la sesión desde la cookie. Sin sesión responde 401 (el front vuelve al login). */
public final class SesionUtil {

    private SesionUtil() {
    }

    public static SessionManager.Sesion requerir(HttpServletRequest request) {
        SessionManager.Sesion sesion = SessionManager.obtener(leerToken(request));
        if (sesion == null) {
            throw new EntregaException(401, "Tu sesión expiró. Inicia sesión de nuevo.");
        }
        return sesion;
    }

    public static String leerToken(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies == null) {
            return null;
        }
        for (Cookie cookie : cookies) {
            if ("fyb_session".equals(cookie.getName())) {
                return cookie.getValue();
            }
        }
        return null;
    }
}
