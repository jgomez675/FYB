package back.entrega.service;

import back.entrega.model.PuntoEntrega;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Catálogo de puntos de entrega. Se lee de data/puntos_entrega.txt
 * (formato: id|nombre|lugar|indicaciones|horario). Si el archivo no existe o está vacío
 * se usan los dos puntos por defecto: Bloque F (Objetos perdidos) y Seguridad.
 */
public class PuntoEntregaService {

    private static final Path ARCHIVO = Paths.get("data", "puntos_entrega.txt");

    private static final Map<String, PuntoEntrega> puntos = new LinkedHashMap<>();

    static {
        cargar();
        if (puntos.isEmpty()) {
            agregar(new PuntoEntrega(
                    "bloque-f",
                    "Bloque F - Objetos perdidos",
                    "Bloque F",
                    "Entrega el objeto en la oficina de Objetos perdidos del bloque F.",
                    ""));
            agregar(new PuntoEntrega(
                    "seguridad",
                    "Seguridad",
                    "Puesto de Seguridad",
                    "Entrega el objeto al personal de Seguridad.",
                    ""));
        }
    }

    private static void cargar() {
        if (!Files.exists(ARCHIVO)) {
            return;
        }

        try (BufferedReader lector = Files.newBufferedReader(ARCHIVO)) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                if (linea.isBlank() || linea.startsWith("#")) {
                    continue;
                }

                String[] p = linea.split("\\|", -1);
                if (p.length == 5 && !p[0].isBlank() && !p[1].isBlank()) {
                    agregar(new PuntoEntrega(p[0].trim(), p[1].trim(), p[2].trim(), p[3].trim(), p[4].trim()));
                }
            }
        } catch (IOException e) {
            System.err.println("No se pudieron cargar los puntos de entrega: " + e.getMessage());
        }
    }

    private static void agregar(PuntoEntrega punto) {
        puntos.put(punto.id(), punto);
    }

    public static List<PuntoEntrega> listar() {
        return new ArrayList<>(puntos.values());
    }

    /** Devuelve el punto, o null si el id no existe. */
    public static PuntoEntrega obtener(String id) {
        return id == null ? null : puntos.get(id.trim());
    }
}
