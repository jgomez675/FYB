package back.entrega;

/** Error de la función de puntos de entrega, con su código HTTP y un mensaje para el usuario. */
public class EntregaException extends RuntimeException {

    private final int estado;

    public EntregaException(int estado, String mensaje) {
        super(mensaje);
        this.estado = estado;
    }

    public int getEstado() {
        return estado;
    }
}
